export const SERVICE_CATEGORIES = [
    'Chimney',
    'Cook top',
    'Electric kettle',
    'Hob',
    'Microwave Oven',
    'Water Purifier',
    'Other Small Appliance',
];

export const PART_CATEGORIES = [
    'Large Appliances',
    'Small Appliances',
    'Consumable',
    'Cook Ware',
    'WA', // As per user's image
    'Accessories',
    'Other',
];
