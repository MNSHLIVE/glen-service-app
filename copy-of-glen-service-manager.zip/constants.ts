
import { Technician } from './types';

export const TECHNICIANS: Technician[] = [
  { id: 'tech1', name: 'Anil Kumar', password: '123', points: 0 },
  { id: 'tech2', name: 'Sunil Sharma', password: '124', points: 0 },
  { id: 'tech3', name: 'Rajesh Verma', password: '125', points: 0 },
];